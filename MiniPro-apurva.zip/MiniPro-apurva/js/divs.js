
$('document').ready(function(){
  
   $(".footer").load("footer.html");


});

$.ajax({ 
    type: 'GET', 
    url: 'http://localhost:3000/posts', 
    data: { get_param: 'value' }, 
    success: function (data) { 
        
        $.each(data,function(i,v){
          
            console.log(v.title);
                let e=
                    "<div class='div1'>" +
                "<b>" +
                v.title +
                    "</b>" +
                    "</br>" +v.description+
                    "<button id="+v.blogid+">Readmore</button>"+
                    "</div>" +"<br><br>";
                    //document.body.appendChild(createButton(v));
                    //console.log(createButton(v));
                    $("#blog").append(e);
                    
        })      
    }
});

// function createButton(v){
//     let editBtn = document.createElement('button');
//     editBtn.textContent="ReadMore "+v.blogid;
//     editBtn.onclick = function(){
//     openURL(v.blogid);
//     };
//     return editBtn;
// }

// function openURL(val){
//     console.log(val);
// }
