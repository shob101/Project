

$('document').ready(function () {

    //    $("#footer").load("../footer.html");

    $("#footer").load("./footer.html")

});


$.ajax({
    type: 'GET',
    url: 'http://localhost:3000/posts',
    data: { get_param: 'value' },
    success: function (data) {

        $.each(data, function (i, v) {

            console.log(v.title);



            let e = '<div class="well">' +
                '<div class="media">' +

                '<div class="media-body">' +
                '<h4 class="media-heading">' + v.title + '</h4>' +
                '<p class="text-left">' + v.blogid + '</p>' + '<p class="text-right">' + v.author + '</p>' +
                '<p>' + v.description + '</p>' +
                '<ul class="list-inline list-unstyled">' +
                '<li><span><i >' + v.category + '</i></span></li>' +
                '<li>' + "|" + '</li>' +
                '<span>' + "2 comments" + '</span>' +
                '<li>' + "|" + '</li>' +
                '<li><i class="fas fa-thumbs-up"></i></li>' +
                '</ul>' +
                '<span><button class="float-right">' + "Read More" + '</button></span>' +
                '</div>' +
                '</div>' +
                '</div>';

            $("#blog").append(e);

            '< ul class = "pagination" >' +
                '<li><a href="#">' + "&laquo;" + '</a></li>' +
                '<li><a href="#">' + "1" + '</a></li>' +
                '<li><a href="#">' + "2" + '</a></li>' +
                '<li><a href="#">' + "3" + '</a></li>' +
                '<li><a href="#">' + "4" + '</a></li>' +
                '<li><a href="#">' + "5" + '</a></li>' +
                '<li><a href="#">' + "&raquo;" + '</a></li>' +
                '</ul >' +

                '<ul class="pager">' +
                '<li><a href="#">' + "Previous" + '</a></li>' +
                '<li><a href="#">' + "  Next  " + '</a></li>' +
                '</ul>';
        })


    }
});

$.ajax({
    type: 'GET',
    url: 'http://localhost:3000/posts',
    data: { get_param: 'value' },
    success: function (data) {

        $.each(data, function (i, v) {

            console.log(v.title);
            let e =
                "<div class='div1'>" +
                "<b>" +
                v.title +
                "</b>" +
                "</br>" + v.description +
                "<button id=" + v.blogid + ">Readmore</button>" +
                "</div>" + "<br><br>";
            //document.body.appendChild(createButton(v));
            //console.log(createButton(v));
            $("#blog").append(e);
        })


    }
});

// function createButton(v){
//     let editBtn = document.createElement('button');
//     editBtn.textContent="ReadMore "+v.blogid;
//     editBtn.onclick = function(){
//     openURL(v.blogid);
//     };
//     return editBtn;
// }

// function openURL(val){
//     console.log(val);
// }
