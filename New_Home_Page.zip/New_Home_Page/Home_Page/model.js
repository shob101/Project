

$(document).ready(function(){
  $("#myBtn").click(function(){
    $("#myModal").modal();
  });
});

// $('signup').click(function(){
//   window.location.replace('./')
// })

function validateForm() {
  console.log("validate");
  var un = document.getElementById('usrname').value
  console.log(un);
  var pw =  document.getElementById('psw').value
  var username = "username"; 
  var password = "password";
  if ((un == username) && (pw == password)) {
    alert("Login Successful");
    // window.location.href = "http://www.w3schools.com";
      return true;
  }
  else {
      alert ("Login was unsuccessful, please check your username and password");
  }
}

