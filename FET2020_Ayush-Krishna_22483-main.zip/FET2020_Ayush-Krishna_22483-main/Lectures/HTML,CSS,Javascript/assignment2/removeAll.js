
function removeAll(item){
    var rows;
    if(item===1)
    rows=document.getElementsByClassName('LSrow');
    else
    rows=document.getElementsByClassName('SSrow');
    
    for(var i=rows.length-1;i>0;i--){
       rows.item(i).remove();
    }

    if(item===1)
    localStorage.clear();
    else
    sessionStorage.clear();
}
