
function detect(){
    if(typeof(Storage) !== "undefined"){
        document.getElementById("detect").innerHTML="Your browser supports both Local Storage and Session Storage."
    }
    else{
        document.getElementById("detect").innerHTML="Your browser does not support Storage."
    }
}

