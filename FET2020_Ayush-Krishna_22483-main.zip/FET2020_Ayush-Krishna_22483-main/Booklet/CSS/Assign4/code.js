function checkTraining()
{
    var c=document.getElementsByName('tr');
    var len=c.length;

    var flag=false;
    for(var i=0;i<len;i++)
    {
        if(c[i].checked==true){
            flag=true;
            break;
        }
    }
    if(flag==false){
        document.getElementById('sub').disabled="true";
        alert("Choose program that you have trained in");
    }
}

function checkDept()
{
    var c=document.getElementsByName('dept');
    var len=c.length;

    var flag=false;
    for(var i=0;i<len;i++){
        if(c[i].checked==true){
            flag=true;
            break;
        }
    }
    if(flag==false){
        document.getElementById('sub').disabled="true";
        alert("Choose your Department");
    }
}

function checkDOB() {
    var dateString = document.getElementById('dat').value;
    var myDate = new Date(dateString);
    var today = new Date();
    if ( myDate > today ) { 
        document.getElementById('out').innerHTML="  Invalid Date";
        document.getElementById('sub').disabled="true";
        return false;
    }
    document.getElementById('sub').disabled="false";
    document.getElementById('out').innerHTML="";
    document.getElementById('sub').removeAttribute("disabled");
    return true;
}