
$(document).ready(function(){
        getAjaxData();
});

function getAjaxData(){
for(var i=1;i<=100;i++){
    $.ajax({
        url:"https://jsonplaceholder.typicode.com/photos/"+i,
        method:"GET",
        success : (x)=>{
            console.log(x);

            var mainDiv = $("<div></div>");
            $(mainDiv).addClass('mydiv');
            
            var gdiv2 = $("<div></div>");
            var gimg= $("<img></img>");
            $(gimg).attr("src",x.thumbnailUrl);
            $(gimg).addClass('myimg');
            $(gimg).appendTo(gdiv2);
            $(mainDiv).append(gdiv2);
            
            var gdiv1 = $("<div></div>");
            $(gdiv1).html(x.title);
            $(gdiv1).css('padding','20px');
            $(mainDiv).append(gdiv1);
            
            var gdiv3 = $("<div></div>");
            
            var btn=$("<button></button>");
            $(btn).addClass('mybtn');
            $(btn).html("Add to cart");
            $(gdiv3).append(btn);
            $(mainDiv).append(gdiv3);

            $(mainDiv).appendTo('#container');

            var x1=document.getElementById("container");
            console.log(x1);
            //$(tr).append("<td>"+x.name+"</td>").append("<td>"+x.username+"</td>").append("<td>"+x.email+"</td>").append("<td>"+x.phone+"</td>").append("<td>"+x.website+"</td>");
            //$('#myTable').append(tr);
        },
        error:(e)=>{
            alert("Error: "+e);
        }
    });
}
}
