
var n = 9;
while (n<1000) {
  n += 1;
  number=n;
  temp=n;
  let final=0;
  while(number>0)
  {
    rem = number%10;
    number = parseInt(number/10);
    final = final*10+rem;
  }
  if(final==temp){
    postMessage(n);
  }
}