function check(){
var pwd=document.getElementById("pass");
var cnfm=document.getElementById("cnfm");
var p=pwd.value;
var c=cnfm.value;
if(p!=c){
    window.alert("Paswwords do not match");   
}
else{
    window.alert("Login successful");   
}
}