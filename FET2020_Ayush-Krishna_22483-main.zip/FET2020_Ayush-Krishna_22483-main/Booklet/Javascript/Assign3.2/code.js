var companyName= "Cybage Software Pvt Ltd";

var div=document.createElement('div');
var lb=document.createElement('label');
lb.textContent="Enter character to be searched : "
lb.padding="10px";
var inp=document.createElement('input');
var btn=document.createElement('button');
btn.textContent="Search";
btn.style.margin="10px"
btn.onclick=function(){
    display(inp.value);
};
div.appendChild(lb);
div.appendChild(inp);
div.appendChild(btn);
document.querySelector('body').appendChild(div);

function display(str){
    if(str.length!=1){
    window.alert("Enter a single character to be searched");
    return;
    }

    var index=companyName.indexOf(str);
    if(index !=-1){
    msg="Character "+str+" found at position "+(index+1);
    }
    else{
        msg="Character "+str+" not found ";
    }

    msg+="<br>"+companyName+" is popularly known as "+companyName.substring(0,15)+"<br>"+companyName.toLowerCase()+"<br>"+companyName.toUpperCase(); 
    var myp=document.createElement('p');
    myp.innerHTML=msg;
    document.querySelector('body').removeChild(div);
    document.querySelector('body').appendChild(myp);
    console.log(index);
}