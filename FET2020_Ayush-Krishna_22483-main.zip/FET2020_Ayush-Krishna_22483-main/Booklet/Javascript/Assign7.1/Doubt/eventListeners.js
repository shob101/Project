console.log("eventlistener.js");

var checkbox = document.getElementById("hobby1");
checkbox.addEventListener('change', function() {
    var x=document.getElementById('myhidden1');
    var y=document.getElementById('myhidden2');
    if(this.checked) {
        x.style.visibility="visible";
        y.style.visibility="visible";
    } else {
        x.style.visibility="hidden";
        y.style.visibility="hidden";
    }
});

var datebox = document.getElementById("date");
var datemsg = document.getElementById("datemsg");
datebox.addEventListener('keyup',function(){
    let txt=datebox.value;
    let c=txt.charAt(txt.length-1);
    if((c.charCodeAt(0)>=48 && c.charCodeAt(0)<=57) || c=='-'){
        datemsg.style.color="black";
        datemsg.textContent="Format : DD-MM-YYYY";
    }
    else{
        datebox.value=txt.slice(0, -1);
        datemsg.style.color="red";
        datemsg.textContent="Invalid character. Please conform to format DD-MM-YYYY"
    }
});
