function validate(){
    console.log("in validate");
    
    var msg=checkFirstName();
    if(msg!=="OK"){
    window.alert(msg);
    return;
    }

    var msg=checkLastName();
    if(msg!=="OK"){
    window.alert(msg);
    return;
    }

    var msg=checkDate();
    if(msg!=="OK"){
    window.alert(msg);
    return;
    }
    
    msg=checkEmail();
    if(msg!=="OK"){
        window.alert(msg);
        return;
    }

    msg=checkHobby();
    if(msg!=="OK"){
        window.alert(msg);
        return;
    }
    
    console.log("test");
    window.location.href = "success.html";
}

function checkFirstName(){
    var n=document.getElementById('fname').value;
    if(n===""){
        return "First name cannot be empty";
    }
    return "OK";
}

function checkLastName(){
    var n=document.getElementById('lname').value;
    if(n===""){
        return "Last name cannot be empty";
    }
    return "OK";
}

function checkEmail(){
    var email=document.getElementById('email').value;
    if(email===""){
        return "Email cannot be empty";
    }

    if(!email.includes('@'))
    return "Email incorrect";
    else
    return "OK";
}

function checkHobby(){
    var hobby1=document.getElementById('hobby1');
    var h1=hobby1.checked;
    var hobby2=document.getElementById('hobby2');
    var h2=hobby2.checked;
    var hobby3=document.getElementById('hobby3');
    var h3=hobby3.checked;
    
    if(!h1 && !h2 && !h3)
    return "No hobby selected";
    else
    return "OK";
}

function checkDate(){
    return "OK";
    var date=document.getElementById('date');
    var d1=Date(date.value);
    var d2=Date(Date.now);

    if(d1.getTime() > d2.getTime()){
        return "Invalid date";
    }

    return "OK";
}

function checkDateFormat(txt){
let flag="true";
let str="";
let count=0;
for(let i=0;i<txt.length;i++){
    let c=txt.charAt(i);
    
    if(c=='-'){
        if(isNaN(str))
            return "Date is invalid";
        else{
            let msg=checkCorrentDatePart(count,str);
            if(msg!=="OK")
            return msg;
        }
        str="";
        count+=1;
    }
    else{
        str+=c;
    }
}
return "OK";
}

function reset(){
    console.log("resetting");
 var fname=document.getElementById('fname');
 fname.value="";
 var lname=document.getElementById('lname');
 lname.value="";
 var date=document.getElementById('date');
 date.value="";
 var email=document.getElementById('email');
 email.value="";
 var hobby1=document.getElementById('hobby1');
 hobby1.checked=false;
 var hobby2=document.getElementById('hobby2');
 hobby2.checked=false;
 var hobby3=document.getElementById('hobby3');
 hobby3.checked=false;
 var hid1=document.getElementById('myhidden1');
 hid1.style.visibility="hidden";
 var hid2=document.getElementById('myhidden2');   
 hid2.value="";
 hid2.style.visibility="hidden";
}