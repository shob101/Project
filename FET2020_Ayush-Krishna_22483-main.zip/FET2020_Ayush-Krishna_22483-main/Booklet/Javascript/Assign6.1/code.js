document.getElementById("myhref").innerHTML = location.href;
document.getElementById("mypath").innerHTML = location.pathname;
document.getElementById("myprotocol").innerHTML = location.protocol;