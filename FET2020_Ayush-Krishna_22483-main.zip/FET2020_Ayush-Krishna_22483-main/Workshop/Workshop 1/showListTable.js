function listAllBooks(){
    display('hidden','hidden','visible');

    let mytable=document.getElementById('mytable');

    let tr = document.createElement('tr');
    createHeader(tr,"Book Title");
    createHeader(tr,"User name");
    createHeader(tr,"Phone");
    mytable.appendChild(tr); 

    for(var i=0;i<myarray.length;i++){
        if(myarray[i].id!==-1)
        {
    let tr = document.createElement('tr');
    tr.id=myarray[i].id;

    let td1 =insertData(tr,myarray[i].book_title);
    let td2 =insertData(tr,myarray[i].user_name);
    let td3 =insertData(tr,myarray[i].phone);

    tr.appendChild(td1);
    tr.appendChild(td2);
    tr.appendChild(td3);
    mytable.appendChild(tr);    
        }
    }
}

function insertData(tr,text){
    let td2 =document.createElement('td');
    let span2 =document.createElement('span');
    span2.textContent=text;
    span2.style.paddingLeft="10px";
    span2.style.paddingRight="10px";
    td2.appendChild(span2);
    tr.appendChild(td2);
    return td2;
}

function createHeader(tr,text){
    let td_1 =document.createElement('td');
    let span_1 =document.createElement('span');
    span_1.textContent=text;
    span_1.style.fontWeight="bold";
    span_1.style.paddingLeft="10px";
    span_1.style.paddingRight="10px";
    td_1.appendChild(span_1);
    tr.appendChild(td_1);
}