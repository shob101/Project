var myarray=[];
var count=0;

function addbook(){
    //console.log("Displaying form to add book");
    var bt= document.getElementById("book_title");
    var un= document.getElementById("user_name");
    var ph= document.getElementById("phone");
    if(bt.value.trim()===""){
        alert("Book name cannot be blank");
        return;
    }
    if(un.value.trim()===""){
        alert("User name cannot be blank");
        return;
    }
    if(ph.value.trim()===""){
        alert("Phone cannot be blank");
        return;
    }
    var nbook={id:count++,book_title:bt.value,user_name:un.value,phone:ph.value};
    bt.value="";
    un.value="";
    ph.value="";
    myarray.push(nbook);
    console.log("Array len = "+myarray.length);
}