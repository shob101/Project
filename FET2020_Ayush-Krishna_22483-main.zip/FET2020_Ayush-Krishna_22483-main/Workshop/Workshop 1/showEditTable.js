function showEditTable(){
    display('hidden','hidden','visible');
    
    let mytable=document.getElementById('mytable');

    let tr = document.createElement('tr');
    createHeader(tr,"Book Title");
    createHeader(tr,"User name");
    createHeader(tr,"Phone");
    createHeader(tr,"Option");
    mytable.appendChild(tr); 

    for(var i=0;i<myarray.length;i++)
    {
        if(myarray[i].id!==-1)
        {
            let tr = document.createElement('tr');
             tr.id=myarray[i].id;

             let td1=insertData(tr,myarray[i].book_title);
             let td2=insertData(tr,myarray[i].user_name);
             let td3=insertData(tr,myarray[i].phone);

            let td4 =document.createElement('td');
            let editBtn = document.createElement('button');
            editBtn.textContent="Edit";
            editBtn.onclick = function(){
                if(editBtn.textContent==="Edit")
                editBook(tr);
                else
                saveBook(tr);
            }
            td4.appendChild(editBtn);

            tr.appendChild(td1);
            tr.appendChild(td2);
            tr.appendChild(td3);
            tr.appendChild(td4);
            mytable.appendChild(tr);
    }
}
}

function insertData(tr,text){
    let td2 =document.createElement('td');
    let span2 =document.createElement('span');
    span2.textContent=text;
    span2.style.paddingLeft="10px";
    span2.style.paddingRight="10px";
    td2.appendChild(span2);
    tr.appendChild(td2);
    return td2;
}

function createHeader(tr,text){
    let td_1 =document.createElement('td');
    let span_1 =document.createElement('span');
    span_1.textContent=text;
    span_1.style.fontWeight="bold";
    td_1.appendChild(span_1);
    tr.appendChild(td_1);
}

function editBook(tr){
    
    console.log(tr.id);
    var span1=tr.children[0].children[0];
    var span2=tr.children[1].children[0];
    var span3=tr.children[2].children[0];
    var btn=tr.children[3].children[0];
    
    btn.textContent="Save";
    btn.style.color = 'red';
    btn.style.borderColor = "red";
    btn.style.backgroundColor = "white";
    span1.contentEditable=true;
    span2.contentEditable=true;
    span3.contentEditable=true;

    // for background grey effect
    tr.style.boxShadow= "0 0 0 100vmax rgba(0,0,0,.3)";
    tr.stylepointerEvents = "none";

    // for setting caret
    var range = document.createRange();
    var sel = window.getSelection();
    range.setStart(span1, 0);
    range.collapse(true);
    sel.removeAllRanges();
    sel.addRange(range);
}

function saveBook(tr){
    
    var btn=tr.children[3].children[0];
    var span1=tr.children[0].children[0];
    var span2=tr.children[1].children[0];
    var span3=tr.children[2].children[0];
    let index=tr.id;
    myarray[index].book_title=span1.textContent;
    myarray[index].user_name=span2.textContent;
    myarray[index].phone=span3.textContent;
    btn.style.color = 'black';
    btn.style.borderColor = "black";
    btn.textContent="Edit";
    tr.style.boxShadow= "none";
    tr.stylepointerEvents = "none";
}