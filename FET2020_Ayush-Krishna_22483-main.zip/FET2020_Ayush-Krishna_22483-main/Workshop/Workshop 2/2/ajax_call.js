

$(document).ready(function(){
    $("#btn1").click(function(){
        getAjaxData();
    })

    $("#btn2").click(function(){
        $('#myTable').DataTable();
    })
    
});

function getAjaxData(){
for(var i=1;i<=10;i++){
    $.ajax({
        url:"http://jsonplaceholder.typicode.com/users/"+i,
        method:"GET",
        success : (x)=>{
            var tr = $("<tr></tr>");
            $(tr).append("<td>"+x.name+"</td>").append("<td>"+x.username+"</td>").append("<td>"+x.email+"</td>").append("<td>"+x.phone+"</td>").append("<td>"+x.website+"</td>");
            $('#myTable').append(tr);
        },
        error:(e)=>{
            alert("Error: "+e);
        }
    });
}
}