var cids=['c1','c2','c3','c4','c5','c6','c7'];
var colors=['red','orange','yellow','red','orange','yellow','orange'];

$(document).ready(function(){
    draw();
    
    $("#b1").click(function(){
      toggleButtons("#b1");
      showCircles("red");
    });

    $("#b2").click(function(){
        toggleButtons("#b2");
        showCircles("orange");
      });

      $("#b3").click(function(){
        toggleButtons("#b3");
        showCircles("yellow");
      });
      
      
      $("#b4").click(function(){
        toggleButtons("#b4");
        showCircles("all");
      });
  });

  function toggleButtons(currid){
    var ids=["#b1","#b2","#b3","#b4"];
    $(currid).css('background-color','green');
    $(currid).css('color','white');
    for(var i=0;i<4;i++){
        if(ids[i]!==currid){
            $(ids[i]).css('background-color','white');
            $(ids[i]).css('color','black');
        }
    }
}

  function showCircles(color){
    for(var i=0;i<7;i++){
        currid="#"+cids[i];
        if(colors[i]!==color && color!=="all")
           $(currid).css( "display", "none");
        else
            $(currid).css( "display", "inline");
    }
  }