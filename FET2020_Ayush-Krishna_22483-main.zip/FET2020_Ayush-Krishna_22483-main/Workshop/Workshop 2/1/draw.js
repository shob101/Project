function draw() {
    for(var i=0;i<7;i++){
    var canvas = document.getElementById(cids[i]);
    if (canvas.getContext) {
      var ctx = canvas.getContext('2d');
      ctx.canvas.width=70;
      ctx.canvas.height=70;
      ctx.beginPath();
      ctx.arc(40, 40, 20, 0, Math.PI * 2, true); // Outer circle
      ctx.stroke();
      ctx.fillStyle = colors[i];
      ctx.fill();
    }
    }
  }