

var blogCount = -1;

var metadata;
var maindata;



if (!window.jQuery) {
    alert("jQuery Unavailable") 
}
else {
    $('document').ready(function(){
        $("#header").load("./header.html")
		
		
		metadata = {
			id: 1,
			title: "Here is a nice Title",
			desc: "Here is a description of the blog",
			category: "CATEGORY",
			tag: ["TAG1","TAG2"]

		};
	
		maindata = {
			id: 2,
			content:
				'<div style="background:#eeeeee;border:1px solid #cccccc;padding:5px 10px;"><big><strong>On a bright sunny morning a group of kids in the neighbourhood found an open field inviting for a game of football.&nbsp; However, there was an issue&mdash;they didn&rsquo;t have a football kit.&nbsp; So, the kids decided that each one of them would bring one item to build the kit.&nbsp; One brought the football, another got the corner flag, and the remaining brought goalkeeper gloves, marking chalk, goalposts, etc.</strong></big></div>\n\n<h3>Everyone gathered on the ground as it was now time to make two teams.&nbsp; But soon, an argument broke out due to lack of consensus on who gets to pick the teams.&nbsp; The kids then determined that the person who had brought the most important item to play, will get to decide the teams.</h3>\n\n<p><img alt="" src="../assets/images/1.jpg" style="border-style:solid; border-width:10px; float:left; margin:10px" />&nbsp;</p>\n\n<p><del>Time pased by and they were still unable to decide the most important thing.&nbsp; Finally, they concluded that they would just start playing with all the items that were brought and then get rid of items one at a time to see which is the most important item left in the end to play the game.</del></p>\n\n<p><small>On a bright sunny morning a group of kids in the neighbourhood found an open field inviting for a game of football.&nbsp; However, there was an issue&mdash;they didn&rsquo;t have a football kit.&nbsp; So, the kids decided that each one of them would bring one item to build the kit.&nbsp; One brought the football, another got the corner flag, and the remaining brought goalkeeper gloves, marking chalk, goalposts, etc.</small></p>\n\n<p>And so, the game started.&nbsp; The first thing they got rid of was the whistle because they felt the referee could shout instead of whistling.&nbsp; Then, the goalkeeper removed his gloves and started saving the ball without them.&nbsp; Moving forward, they replaced the goalpost with a couple of bins on each side.&nbsp; Eventually, they replaced the football with an old tin and continued to play.&nbsp; Then after some time, with no proper kit or team formation, they got tired of playing a listless game and it was called off.</p>\n\n<hr />\n<p><img alt="" src="../assets/images/1.jpg" style="border-style:solid; border-width:10px; float:right; margin:10px" />&nbsp;</p>\n\n<p>And so, the game started.&nbsp; The first thing they got rid of was the whistle because they felt the referee could shout instead of whistling.&nbsp; Then, the goalkeeper removed his gloves and started saving the ball without them.&nbsp; Moving forward, they replaced the goalpost with a couple of bins on each side.&nbsp; Eventually, they replaced the football with an old tin and continued to play.&nbsp; Then after some time, with no proper kit or team formation, they got tired of playing a listless game and it was called off.​​​​​​​</p>\n\n<p><em>Often, in today&rsquo;s world, we become so competitive that our aspiration to be a leader compromises our ability to even be a good team member!&nbsp; Our competitiveness, without collaborative spirit, is counterproductive.&nbsp; Sure, we may succeed to a degree without team effort.&nbsp; But the degree of that success is equivalent to winning a football game being played with tin-cans!&nbsp;</em></p>\n\n<p><u><strong>Team initiatives, on the other hand, help us win games that are of consequence!</strong></u></p>\n\n<table border="1" cellpadding="1" cellspacing="1" summary="gsdfgsd">\n\t<caption>Test</caption>\n\t<tbody>\n\t\t<tr>\n\t\t\t<td>fghdf6789</td>\n\t\t\t<td>dfghdfg</td>\n\t\t</tr>\n\t\t<tr>\n\t\t\t<td>ertyery8</td>\n\t\t\t<td>ertyery</td>\n\t\t</tr>\n\t\t<tr>\n\t\t\t<td>fdhfdghncvbn</td>\n\t\t\t<td>iuop89o789</td>\n\t\t</tr>\n\t</tbody>\n</table>\n\n<p>&nbsp;</p>\n\n<p>Once there lived a man who was always scared and would run away from everything he feared.&nbsp; Tired of living a scared life, he went to a wise man for guidance, &ldquo;Master, I have been a coward all my life.&nbsp; Please teach me to be brave.&rdquo;</p>\n\n<p>&ldquo;Sure, but only on one condition,&rdquo; Master replied. &nbsp;&ldquo;For one month, every stranger who crosses your path, tell them &ldquo;I am a coward&rdquo; and say it loudly while looking straight into their eyes.&rdquo;</p>\n\n<p>The man panicked at the prospect of these humiliating encounters.&nbsp; For the first couple of days, he trembled with fear at the sight of a passerby. &nbsp;But he knew that he had to finish this difficult task if he wished to be brave.&nbsp; So, on the third day, he mustered all his courage and managed to utter softly, &ldquo;I am a coward,&rdquo; to one of the passersby.</p>\n\n<p><u>Then something interesting unfolded.&nbsp; With each passing day, his voice grew louder and more confident.&nbsp; Within days the man was no longer scared and could easily execute the task that was assigned to him.&nbsp; At the end of the month, the man came back to the Master and bowed down, &ldquo;Thank you, Master. &nbsp;I finished your task. &nbsp;Now, I am not afraid anymore.&nbsp; But, I do have a question.&nbsp; How did you know that this strange task will help me overcome my fear?&rdquo;</u></p>\n\n<p><u>&Ntilde;&Acirc;t►&yuml;&aelig;</u></p>\n\n<hr />\n<p>&nbsp;</p>\n',
		};

		$('#reader_title').text(metadata.title);
		$('#reader_desc').text(metadata.desc);
		$('#reader_cat a').text(metadata.category);
		metadata.tag.forEach((tag)=>{
			$('#reader_tag').append("<li>"+tag+ "</li>");
		});
		$('#reader_blogcontent').html(maindata.content);

		$("#footer").load("./footer.html")
	});
}
