function additem(pos){

    let keyinput=document.getElementById('keyinput');
    let valueinput=document.getElementById('valueinput');
    let keytxt=keyinput.value;
    let valuetxt=valueinput.value;
    if(keytxt.trim()===""){
        alert("Key cannot be blank");
        return;
    }
    if(valuetxt.trim()===""){
        alert("Value cannot be blank");
        return;
    }
    valueinput.value="";
    keyinput.value="";
    //console.log(keytxt+" ; "+valuetxt);
    
    if(pos===1)
    localStorage.setItem(keytxt, valuetxt);
    else
    sessionStorage.setItem(keytxt, valuetxt);

    let mytable;
    if(pos==1)
    mytable=document.getElementById('LStable');
    else
    mytable=document.getElementById('SStable');

    let tr = document.createElement('tr');
    if(pos===1)
    tr.className="LSrow";
    else
    tr.className="SSrow";

    let td1 =document.createElement('td');
    let span1 =document.createElement('span');
    span1.textContent=keytxt;
    td1.appendChild(span1);
    tr.appendChild(td1);

    let td2 =document.createElement('td');
    let span2 =document.createElement('span');
    span2.textContent=valuetxt;
    td2.appendChild(span2);
    tr.appendChild(td2);
    
    let td3 =document.createElement('td');
    let listBtn = document.createElement('button');
    //listBtn.style.marginLeft='10px';
    listBtn.textContent="Delete";
    listBtn.onclick = function(){
        mytable.removeChild(tr);
        if(pos===1)
        localStorage.removeItem(keytxt, valuetxt);
        else
        sessionStorage.removeItem(keytxt, valuetxt);
    }
    td3.appendChild(listBtn)

    tr.appendChild(td1);
    tr.appendChild(td2);
    tr.appendChild(td3);
    mytable.appendChild(tr);
}
