$(document).ready(function(){
    $(".myhead").css({
        "height":"100px",
        "border":"1px solid red"
    });
    
    $(".mydiv").css({
        "border":"2px solid black",
        "display":"flex",
        "height":"400px"
    });
    
    $(".mysect").css({
        "border":"2px solid blue",
        "margin":"10px"
    });
    
    $(".myaside1").css({
        "border":"2px solid blue",
        "margin":"10px"
    });
    
    $(".myaside2").css({
        "border":"2px solid blue",
        "margin":"10px"
    });
    
    $(".myfooter").css({
        "height":"100px",
        "width":"100%",
        "border":"1px solid red",
        "position":"absolute",                 
        "bottom":"0"    
    });

    $(".myhead").html("<h1>Head</h1>");
    $(".myfooter").html("<h1>Foot</h1>");
});