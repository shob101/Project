function display(intr,myfrm,myhead){
    //console.log("btn");
    var intro= document.getElementById("intro");
    intro.style.visibility = intr ;
    var myform= document.getElementById("myform");
    myform.style.visibility = myfrm ;
    var myform= document.getElementById("myheading");
    myform.style.visibility = myhead;
    
    deletePreviousTable();
}

function deletePreviousTable(){
    var element = document.querySelectorAll("tr");
    Array.prototype.forEach.call( element, function( node ) {
        node.parentNode.removeChild( node );
    });
}