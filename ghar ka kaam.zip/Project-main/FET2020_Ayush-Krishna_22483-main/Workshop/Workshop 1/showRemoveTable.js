function showAndRemove(){
    display('hidden','hidden','visible');

    let mytable=document.getElementById('mytable');

    let tr = document.createElement('tr');
    createHeader(tr,"Book Title");
    createHeader(tr,"User name");
    createHeader(tr,"Option");
    mytable.appendChild(tr);   
   
    for(var i=0;i<myarray.length;i++){
        if(myarray[i].id!==-1){
    let tr = document.createElement('tr');
    tr.id=myarray[i].id;
    
    let td1 =document.createElement('td');
    let span1 =document.createElement('span');
    span1.textContent=myarray[i].book_title;
    td1.appendChild(span1);
    tr.appendChild(td1);

    let td2 =document.createElement('td');
    let span2 =document.createElement('span');
    span2.textContent=myarray[i].user_name;
    td2.appendChild(span2);
    tr.appendChild(td2);
    
    let td3 =document.createElement('td');
    let listBtn = document.createElement('button');
    listBtn.textContent="Delete";
    listBtn.onclick = function(){
        mytable.removeChild(tr);
        mydelete(tr.id);
    }
    td3.appendChild(listBtn)

    tr.appendChild(td1);
    tr.appendChild(td2);
    tr.appendChild(td3);
    mytable.appendChild(tr);    
        }
    }
}

function createHeader(tr,text){
    let td_1 =document.createElement('td');
    td_1.style.padding="20px";
    let span_1 =document.createElement('span');
    span_1.textContent=text;
    span_1.style.fontWeight="bold";
    td_1.appendChild(span_1);
    tr.appendChild(td_1);
}

function mydelete(index){
    console.log(index);
    myarray[index].id=-1;
    myarray[index].phone=null;
    myarray[index].book_title=null;
    myarray[index].user_name=null;
}