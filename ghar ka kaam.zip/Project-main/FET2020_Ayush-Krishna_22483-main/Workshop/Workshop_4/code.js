document.body.style.backgroundImage = "url('back.jpeg')";

function validate(){
    console.log("hello");
    var pass=document.getElementById("password");
    var confirm=document.getElementById("cnfm_password");
    var passmsg=document.getElementById("msg");
    var phone=document.getElementById("phone");
    var phmsg=document.getElementById("phmsg");
    passmsg.style.color="red";
    phmsg.style.color="red";
    if(pass.value!==confirm.value){
        passmsg.innerHTML="Passwords do not match";
    }
    else{
        passmsg.innerHTML="";
    }

    if(phone.value.length!=10){
        phmsg.innerHTML="Phone number must be of 10 digits";
    }
    else{
        phmsg.innerHTML="";
    }

}