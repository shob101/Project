var names=[];

function add(){
    let d=document.createElement('div');
    let inp=document.createElement('input');
    let addB=document.createElement('button');
    addB.style.margin="10px";
    addB.textContent="Add";
    addB.onclick=function (){
        let txt=inp.value;
        inp.value="";
        if(txt.trim().length==0){
            window.alert("Name cannot be empty");
            return;
        }
        names.push(txt.trim());
    }
    
    let dispB=document.createElement('button');
    dispB.style.margin="10px";
    dispB.textContent="Display";
    dispB.onclick=function(){
        let head=document.createElement('h2');
        head.innerHTML="List of Students <br> --------------------------";
        let d2=document.createElement('div');
        d2.appendChild(head);
        for(var i=0;i<names.length;i++){
            let myp=document.createElement('p');
            myp.innerHTML=names[i];
            d2.appendChild(myp);
        }
        let body=document.querySelector('body');
        body.removeChild(d);
        body.appendChild(d2);
    }

    d.appendChild(inp);
    d.appendChild(addB);
    d.appendChild(dispB);
    let body=document.querySelector('body');
    body.appendChild(d);
}