var msg;
msg="The script is located in external script file called math.js.";

function addNumbers(headParam, bodyParam)
{
msg=msg+"<br><br> The addition of "+headParam+" and "+bodyParam+" is "+(headParam+bodyParam);
var x=document.querySelector('p');
x.innerHTML=msg;
}