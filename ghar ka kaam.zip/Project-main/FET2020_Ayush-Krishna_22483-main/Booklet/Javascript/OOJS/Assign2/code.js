var str="";
var scr=document.getElementById('screen');
var visible=false;
function input(inp){

console.log(inp);

switch(inp) {
  
    case "SW":
    let a=document.getElementsByClassName("grid-button-hidden");
        if(!visible){
            for(let i=0;i<a.length;i++)
            a[i].style.visibility="visible";
            visible=true;
        }
        else{
            for(let i=0;i<a.length;i++)
            a[i].style.visibility="hidden";
            visible=false;
        }
    break;

    case "BKS":
    if(str.length>0){
    str=str.slice(0, -1);
    scr.textContent=str;
    }
    break;

    case "C":
    str="";
    scr.textContent=str;
    break;

    case "=":
    if(str.length>0){
    try {
        str=eval(str)+"";
        scr.textContent=str;
      }
      catch(err) {
        console.log("error "+err);  
        scr.textContent="Invalid Expression";
        str="";
    }
    }
    break;

    case "rt":
        if(str.length>0){
        str=eval(str);
        str=Math.sqrt(str)+"";
        scr.textContent=str;  
        }  
    break;

    case "cube":
        if(str.length>0){
        str=eval(str);
        str=Math.pow(str,3)+"";
        scr.textContent=str; 
        }
    break;

    case "squ":
        if(str.length>0){
        str=eval(str);
        str=Math.pow(str,2)+"";
        scr.textContent=str; 
        }
    break;

default:
    str+=inp;
    scr.textContent=str;
    break;    
}

}
