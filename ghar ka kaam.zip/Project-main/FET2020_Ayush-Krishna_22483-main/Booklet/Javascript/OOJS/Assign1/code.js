alert("This program calculates area/perimeter assuming the coordinates entered are correct by the user. It does not check whether entered coordinates forms given quadrilaterals or not so enter coordinates correctly for square/rectangle/triangle");

var pts=[];

function clearAll(){
    console.log("clear all");
    pts=[];
    let list=document.getElementById("list");
    list.textContent="Entered Coordinates :";
}

function addPoint(){
    let xc=document.getElementById("x-cd");
    let xval=xc.value;
    if(xval.length==0)
    {
        alert("Enter x coordinate");
        return;
    }
    xc.value="";
    let yc=document.getElementById("y-cd");
    let yval=yc.value;
    if(yval.length==0)
    {
        alert("Enter y coordinate");
        return;
    }
    yc.value="";
    pts.push(new Point(xval,yval));
    let list=document.getElementById("list");
    list.textContent+="("+xval+","+yval+"),";
}

function printTriangleArea(){
    let tri=new Triangle(pts.length,pts);
    tri.area();
}

function printTrianglePeri(){
    let tri=new Triangle(pts.length,pts);
    tri.perimeter();
}

function printSquareArea(){
    let sq=new Square(pts.length,pts);
    sq.area();
}

function printRectArea(){
    let rect=new Rectangle(pts.length,pts);
    rect.area();
}

function printSquarePeri(){
    let sq=new Square(pts.length,pts);
    sq.perimeter();
}

function printRectPeri(){
    let rect=new Rectangle(pts.length,pts);
    rect.perimeter();
}