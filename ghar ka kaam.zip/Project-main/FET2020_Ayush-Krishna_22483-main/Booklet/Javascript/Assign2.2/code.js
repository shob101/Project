
function calc(){
    let msg="";
    let p=document.querySelector('p');
    
    console.log("i = "+i);
}