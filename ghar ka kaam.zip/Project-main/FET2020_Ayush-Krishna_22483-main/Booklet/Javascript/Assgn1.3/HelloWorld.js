function sayHello(){
    return "Hello from JavaScript";
}