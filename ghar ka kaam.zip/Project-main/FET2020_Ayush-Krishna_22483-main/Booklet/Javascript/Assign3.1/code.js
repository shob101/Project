var days=["Sun","Mon","Tue","Wed","Thur","Fri","Sat"];
var months=["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sept","Oct","Nov","Dec"];
var dt=new Date(Date.now());
var day=dt.getDay();
var month=dt.getMonth()
var dat=dt.getDate();
var year=dt.getFullYear();
var hr=dt.getHours();
var min=dt.getMinutes();
var sec=dt.getSeconds();
var h;
var greet;
if(hr < 12){
    greet = "Good morning!!!";
    h="AM"
}
else if(hr >= 12 && hr<=17){
    greet = "Good afternoon!!!";
    h="PM"
}
else{
    greet = "Good evening!!!";
    h="PM";
}
if(hr>12)
hr-=12;

msg=days[day]+" "+months[month]+" "+dat+" "+year+" "+hr+":"+min+":"+sec+" "+h+"<br>"+greet;
document.getElementById("res").innerHTML=msg;

//console.log(day+" ; "+month+" ; "+dat+" ; "+year);