
    let msg="";
    let p=document.querySelector('p');
    let i=1;
    while(i<=100){
        msg=msg+i+" ";
        if(i%10==0){
            let old=p.innerHTML;
            old+=msg+"<br>";
            p.innerHTML=old;
            msg="";
        }
        i++;
    }
    console.log("i = "+i);