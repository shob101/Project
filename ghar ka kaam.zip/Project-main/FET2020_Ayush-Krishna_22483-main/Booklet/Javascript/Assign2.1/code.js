
    let msg="";
    let p=document.querySelector('p');
    let i=1;
    for(;i<=100;i++){
        msg=msg+i+" ";
        if(i%10==0){
            let old=p.innerHTML;
            old+=msg+"<br>";
            p.innerHTML=old;
            msg="";
        }
    }
    console.log("i = "+i);