
var x=document.getElementById('hx');
var cx=x.getContext("2d");
cx.beginPath();

cx.arc(100,100,50,0,2*Math.PI);
cx.stroke();
cx.fillStyle="yellow";
cx.fill();

cx.beginPath();
cx.arc(80,80,10,0,2*Math.PI)
cx.fillStyle="black";
cx.fill();

cx.beginPath();

cx.arc(120,80,10,0,2*Math.PI)
cx.fillStyle="black";
cx.fill();

cx.beginPath();

cx.arc(100,110,20,0,1*Math.PI)
cx.stroke();