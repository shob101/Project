function calc(){
    let txt=document.getElementById('amount').textContent;
    let xyz=document.getElementById('pay');
    let p=txt-(0.1*txt);
    xyz.textContent=p;
}