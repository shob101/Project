//console.log("hello");
var reqwidth=800;
var vnav=document.getElementById("vnav");
vnav.style.display="none";
var btn=document.getElementById("vnavbutton");
var hnav=document.getElementById("hnav");

if(screen.width<reqwidth){
    console.log("screen < "+reqwidth);
    hnav.style.display="none";
    btn.style.display="block";
}
else{
    console.log("screen > "+reqwidth);
    hnav.style.display="block";
    btn.style.display="none";
}

var mediaQueryList = window.matchMedia('(max-width: '+reqwidth+'px)');
mediaQueryList.addEventListener('change',screenTest);

function screenTest(e) {
  if (e.matches) {
    /* the viewport is 600 pixels wide or less */
    //console.log("<=600px");
    vnav.style.display="none";
    hnav.style.display="none";
    btn.style.display="block";
    //document.body.style.backgroundColor = 'pink';
  } 
  else {
    /* the viewport is more than than 600 pixels wide */
    //console.log(">600px");
    hnav.style.display="block";
    btn.style.display="none";
    vnav.style.display="none";
    //document.body.style.backgroundColor = 'aquamarine';
  }
}

function toggleNavbar(){
    let nv=document.getElementById("vnav");
    if(nv.style.display==="block"){
        nv.style.display="none";
    }
    else{
        nv.style.display="block";
    }
}