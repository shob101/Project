
var main=document.getElementById("main");
main.addEventListener("mouseover",edit);

function edit(){
    console.log("in edit");
    var txt=document.getElementById("text");
    var bc=document.getElementById("backcolor");
    var fc=document.getElementById("fontcolor");
    
    if(txt.value.length>0){
        main.innerHTML=txt.value.toUpperCase();
        txt.value="";
    }

    if(bc.value.length>0){
        main.style.backgroundColor=bc.value;
        bc.value="";
    }

    if(fc.value.length>0){
        main.style.color=fc.value;
        fc.value="";
    }

}