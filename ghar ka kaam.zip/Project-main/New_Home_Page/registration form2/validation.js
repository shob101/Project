if (!window.jQuery) {
    alert("jQuery Unavailable")
}
else {
    $(document).ready(function () {

        $('#header').load('header.html');
        $('#footer').load('footer.html');

        $flag = 1;
        $("#myName").focusout(function () {
            if ($(this).val() == '') {
                $(this).css("border-color", "#FF0000");
                $('#submit').attr('disabled', true);
                $("#error_name").text("* You have to enter your first name!");
            }
            else {
                $(this).css("border-color", "#2eb82e");
                $('#submit').attr('disabled', false);
                $("#error_name").text("");

            }
        });
        $("#lastname").focusout(function () {
            if ($(this).val() == '') {
                $(this).css("border-color", "#FF0000");
                $('#submit').attr('disabled', true);
                $("#error_lastname").text("* You have to enter your Last name!");
            }
            else {
                $(this).css("border-color", "#2eb82e");
                $('#submit').attr('disabled', false);
                $("#error_lastname").text("");
            }
        });
        $("#email").focusout(function () {
            if ($(this).val() == '') {
                $(this).css("border-color", "#FF0000");
                $('#submit').attr('disabled', true);
                $("#error_email").text("* You have to enter your Email!");
            }
            else {
                $(this).css("border-color", "#2eb82e");
                $('#submit').attr('disabled', false);
                $("#error_email").text("");
            }
        });
        $("#password").focusout(function () {
            if ($(this).val() == '') {
                $(this).css("border-color", "#FF0000");
                $('#submit').attr('disabled', true);
                $("#error_password").text("* You have to enter your Password!");
            }
            
            else {
                $(this).css("border-color", "#2eb82e");
                $('#submit').attr('disabled', false);
                $("#error_password").text("");
            }
        });
        $("#confirm_password").focusout(function () {
            if ($(this).val() == '') {
                $(this).css("border-color", "#FF0000");
                $('#submit').attr('disabled', true);
                $("#error_confirm_password").text("* You have to enter your Confirm Password!");
            }

            else if ($('#password').val() == $('#confirm_password').val()) {
                // alert("match");
                $("#error_confirm_password").text("Password are match");
                $("#error_confirm_password").css("color", "green");
            }

           
            else {
                $(this).css("border-color", "#2eb82e");
                $('#submit').attr('disabled', false);
                $("#error_confirm_password").text("password are not match");
            }
        });

        $("#dob").focusout(function () {
            if ($(this).val() == '') {
                $(this).css("border-color", "#FF0000");
                $('#submit').attr('disabled', true);
                $("#error_dob").text("* You have to enter your Date of Birth!");
            }
            else {
                $(this).css("border-color", "#2eb82e");
                $('#submit').attr('disabled', false);
                $("#error_dob").text("");
            }
        });

        // $("#gender").focusout(function () {
        //     $(this).css("border-color", "#2eb82e");

        // });


        // $("#age").focusout(function () {
        //     if ($(this).val() == '') {
        //         $(this).css("border-color", "#FF0000");
        //         $('#submit').attr('disabled', true);
        //         $("#error_age").text("* You have to enter your Age!");
        //     }
        //     else {
        //         $(this).css({ "border-color": "#2eb82e" });
        //         $('#submit').attr('disabled', false);
        //         $("#error_age").text("");

        //     }
        // });

        // $("#confirm_password").focunsout(function () {
        //     $pass=$('password').val();
        //     if ($('password').val() == $('confirm_password').val()) {
        //         alert("match");
        //         $("#error_confirm_password").text("Password are match");
        //         $("#error_confirm_password").css("color", "green");
        //     }
        //     else {
        //         alert("unmatch");
        //         $("#confirm_password").css("border-color", "#FF0000");
        //         $('#submit').attr('disabled', true);
        //         $("#error_confirm_password").text("* Password are not match!");
        //     }
    
        // });


        // $("#phone").focusout(function () {
        //     $pho = $("#phone").val();
        //     if ($(this).val() == '') {
        //         $(this).css("border-color", "#FF0000");
        //         $('#submit').attr('disabled', true);
        //         $("#error_phone").text("* You have to enter your Phone Number!");
        //     }
        //     else if ($pho.length != 10) {
        //         $(this).css("border-color", "#FF0000");
        //         $('#submit').attr('disabled', true);
        //         $("#error_phone").text("* Lenght of Phone Number Should Be Ten");
        //     }
        //     else if (!$.isNumeric($pho)) {
        //         $(this).css("border-color", "#FF0000");
        //         $('#submit').attr('disabled', true);
        //         $("#error_phone").text("* Phone Number Should Be Numeric");
        //     }
        //     else {
        //         $(this).css({ "border-color": "#2eb82e" });
        //         $('#submit').attr('disabled', false);
        //         $("#error_phone").text("");
        //     }

        // });

        $("#submit").click(function () {
            if ($("#myName").val() == '') {
                $("#myName").css("border-color", "#FF0000");
                $('#submit').attr('disabled', true);
                $("#error_name").text("* You have to enter your first name!");
            }
            if ($("#lastname").val() == '') {
                $("#lastname").css("border-color", "#FF0000");
                $('#submit').attr('disabled', true);
                $("#error_lastname").text("* You have to enter your Last name!");
            }
            if ($("#email").val() == '') {
                $("#email").css("border-color", "#FF0000");
                $('#submit').attr('disabled', true);
                $("#error_email").text("* You have to enter your Email!");
            }
            if ($("#password").val() == '') {
                $("#password").css("border-color", "#FF0000");
                $('#submit').attr('disabled', true);
                $("#error_password").text("* You have to enter your password!");
            }
            if ($("#confirm_password").val() == '') {
                $("#confirm_password").css("border-color", "#FF0000");
                $('#submit').attr('disabled', true);
                $("#error_confirm_password").text("* You have to enter your confirm password!");
            }

            if ($("#dob").val() == '') {
                $("#dob").css("border-color", "#FF0000");
                $('#submit').attr('disabled', true);
                $("#error_dob").text("* You have to enter your Date of Birth!");
            }
            // if ($("#age").val() == '') {
            //     $("#age").css("border-color", "#FF0000");
            //     $('#submit').attr('disabled', true);
            //     $("#error_age").text("* You have to enter your Age!");
            // }
            // if ($("#phone").val() == '') {
            //     $("#phone").css("border-color", "#FF0000");
            //     $('#submit').attr('disabled', true);
            //     $("#error_phone").text("* You have to enter your Phone Number!");
            // }
        });

    //     $("confirm_password").focusout(function () {
    //     if ($('#password').val() == $('#confirm_password').val()) {
    //         // alert("match");
    //         $("#error_confirm_password").text("Password are match");
    //         $("#error_confirm_password").css("color", "green");
    //     }
    //     else {
    //         // alert("unmatch");
    //         $("#confirm_password").css("border-color", "#FF0000");
    //         $('#submit').attr('disabled', true);
    //         $("#error_confirm_password").text("* Password are not match!");
    //     }

    // });
   

    });

    // $('#footer').load('./footer.html');
}
